"""Service authentication providers."""
